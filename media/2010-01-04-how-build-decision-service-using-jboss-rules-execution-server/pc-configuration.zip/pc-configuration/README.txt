Drools Excecution Server example

This is a simple example of a decision service, implemented using JBoss Rules.
This example uses the Drools Execution Server; no Java code is required.
See http://www.lunatech-research.com/ �
